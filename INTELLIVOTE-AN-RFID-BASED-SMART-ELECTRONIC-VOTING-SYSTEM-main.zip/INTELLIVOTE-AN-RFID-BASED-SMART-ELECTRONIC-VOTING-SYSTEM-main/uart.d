.\uart.o: uart.c
.\uart.o: uart_defines.h
.\uart.o: D:\ARM\Inc\Philips\lpc21xx.h
.\uart.o: delay.h
